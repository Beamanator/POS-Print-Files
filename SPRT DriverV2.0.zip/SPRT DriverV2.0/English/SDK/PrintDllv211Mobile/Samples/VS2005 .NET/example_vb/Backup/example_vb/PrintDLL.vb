Imports System.Runtime.InteropServices

Namespace PrintCENET

    Public Class PrintCE_LoadLib_Exception
        Inherits System.Exception
        Public Overrides ReadOnly Property Message() As String
            Get
                Return "PrintDLL.dll not found"
            End Get
        End Property
    End Class

    Public Enum PrinterType
        SPRT_PT_TIII_TIV = 0
        SPRT_PT_T5
        SPRT_PT_T8
    End Enum

    Public Enum PrintOrientation
        SPRT_PO_PORTRAIT = 0
        SPRT_PO_LANDSCAPE
    End Enum

    Public Enum ConnectedStatus
        SPRT_CS_NOTINITED = 0
        SPRT_CS_NORMAL
        SPRT_CS_IDLE
        SPRT_CS_BUSY
    End Enum

    Public Enum PrinterStatus
        SPRT_PS_NORMAL = 0
        SPRT_PS_OUTPAPER
        SPRT_PS_ERROR
    End Enum

    Public Enum MapMode
        SPRT_MM_DOT = 0
        SPRT_MM_INCH
        SPRT_MM_MM
    End Enum

    Public Structure ComState
        Public dwBaudRate As Int32
        Public Parity As Byte
        Public StopBits As Byte
    End Structure
    Public Structure PrintInfo
        Public printType As PrinterType
        Public printOrient As PrintOrientation
        Public paperWidth As Double
        Public paperHeight As Double
        Public bRoll As Int32
        Public port As Int32
        Public pcs As IntPtr
    End Structure
    Public Structure FontProperty
        Public bDefault As Boolean
        Public bUnderLine As Boolean
        Public bItalic As Boolean
        Public bStrikeout As Boolean
        Public nWidth As Int32
        Public nHeight As Int32
        Public iCharSet As Int32
        Public iWeight As Int32
    End Structure

    Public Class PrintDC

        Public Sub New()
            If LoadLibrary("PrintCE.dll") = 0 Then
                Throw (New PrintCE_LoadLib_Exception)
            End If
        End Sub
        <DllImport("CoreDll.dll", EntryPoint:="LoadLibrary", SetLastError:=True)> _
        Private Shared Function LoadLibrary(ByVal lpFileName As String) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_StartDoc")> _
        Private Shared Function DC_StartDoc() As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_StartPage")> _
        Private Shared Function DC_StartPage() As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_EndDoc")> _
        Private Shared Function DC_EndDoc() As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_PrinterSet")> _
        Private Shared Function DC_PrinterSet(ByVal pi As PrintInfo) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_GetConnectedStatus")> _
        Private Shared Function DC_GetConnectedStatus() As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_GetDevCaps")> _
        Private Shared Function DC_GetDevCaps(ByVal devcap As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_GetMapMode")> _
        Private Shared Function DC_GetMapMode() As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_SetMapMode")> _
        Private Shared Function DC_SetMapMode(ByVal mm As MapMode) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_SetFont")> _
        Private Shared Function DC_SetFont(ByVal fp As FontProperty) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_SetFontName")> _
        Private Shared Function DC_SetFontName(ByVal str As String) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_PrintText")> _
        Private Shared Function DC_PrintText(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_PrintTextBlock")> _
        Private Shared Function DC_PrintTextBlock(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal width As Double, ByVal height As Double, ByVal iFormat As Int32) As Integer
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_SetBorderMode")> _
        Private Shared Function DC_SetBorderMode(ByVal bFill As Boolean) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_SetFillMode")> _
        Private Shared Function DC_SetFillMode(ByVal bFill As Boolean) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_GetLineWidth")> _
        Private Shared Function DC_GetLineWidth(ByRef width As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_SetLineWidth")> _
        Private Shared Function DC_SetLineWidth(ByVal width As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawEllips")> _
        Private Shared Function DC_DrawEllips(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawLine")> _
        Private Shared Function DC_DrawLine(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawRect")> _
        Private Shared Function DC_DrawRect(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawRoundRect")> _
        Private Shared Function DC_DrawRoundRect(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double, ByVal width As Double, ByVal height As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawCircle")> _
        Private Shared Function DC_DrawCircle(ByVal x As Double, ByVal y As Double, ByVal radius As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_GetPictureSize")> _
        Private Shared Function DC_GetPictureSize(ByVal filepath As String, ByRef width As Double, ByRef height As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_PrintPicture")> _
        Private Shared Function DC_PrintPicture(ByVal filepath As String, ByVal x As Double, ByVal y As Double, ByVal width As Double, ByVal height As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_SetBarcodeHeight")> _
        Private Shared Function DC_SetBarcodeHeight(ByVal height As Double) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_Draw2of5")> _
        Private Shared Function DC_Draw2of5(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal checksum As Boolean, ByVal add_text As Boolean, ByVal thickness As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawCodaBar")> _
        Private Shared Function DC_DrawCodaBar(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawCode128")> _
        Private Shared Function DC_DrawCode128(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal advance As Boolean, ByVal thickness As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawCode39")> _
        Private Shared Function DC_DrawCode39(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal checksum As Boolean, ByVal add_text As Boolean, ByVal thickness As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawCode93")> _
        Private Shared Function DC_DrawCode93(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawUPCA")> _
        Private Shared Function DC_DrawUPCA(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawUPCE")> _
        Private Shared Function DC_DrawUPCE(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawEAN13")> _
        Private Shared Function DC_DrawEAN13(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="DC_DrawEAN8")> _
        Private Shared Function DC_DrawEAN8(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Int32) As Int32
        End Function

        Public ReadOnly Property ConnectedStatus() As ConnectedStatus
            Get
                Return DC_GetConnectedStatus()
            End Get
        End Property
        Public Property MapMode() As MapMode
            Get
                Dim width As Double
                width = DC_GetMapMode()
                Return width
            End Get

            Set(ByVal Value As MapMode)
                DC_SetMapMode(Value)
            End Set
        End Property
        Public WriteOnly Property BorderMode() As Boolean
            Set(ByVal Value As Boolean)
                DC_SetBorderMode(Value)
            End Set
        End Property
        Public WriteOnly Property FillMode() As Boolean
            Set(ByVal Value As Boolean)
                DC_SetFillMode(Value)
            End Set
        End Property
        Public Property LineWidth() As Double
            Get
                Dim width As Double
                Return DC_GetLineWidth(width)
            End Get

            Set(ByVal Value As Double)
                DC_SetLineWidth(Value)
            End Set
        End Property
        Public WriteOnly Property BarcodeHeight() As Double
            Set(ByVal Value As Double)
                DC_SetBarcodeHeight(Value)
            End Set
        End Property

        Public Function StartDoc() As Int32
            Return DC_StartDoc()
        End Function
        Public Function StartPage() As Int32
            Return DC_StartPage()
        End Function
        Public Function EndDoc() As Int32
            Return DC_EndDoc()
        End Function
        Public Function PrinterSet(ByVal pi As PrintInfo) As Int32
            Return DC_PrinterSet(pi)
        End Function
        Public Function GetDevCaps(ByVal devcap As Int32) As Int32
            Return DC_GetDevCaps(devcap)
        End Function
        Public Function SetFont(ByVal fp As FontProperty) As Int32
            Return DC_SetFont(fp)
        End Function
        Public Function SetFontName(ByVal lpString As String) As Int32
            Return DC_SetFontName(lpString)
        End Function
        Public Function PrintText(ByVal lpString As String, ByVal pos_x As Double, ByVal pos_y As Double) As Int32
            Return DC_PrintText(lpString, pos_x, pos_y)
        End Function
        Public Function PrintTextBlock(ByVal lpString As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal width As Double, ByVal height As Double, ByVal iFormat As Int32) As Int32
            Return DC_PrintTextBlock(lpString, pos_x, pos_y, width, height, iFormat)
        End Function
        Public Function DrawEllips(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double) As Int32
            Return DC_DrawEllips(x1, y1, x2, y2)
        End Function
        Public Function DrawLine(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double) As Int32
            Return DC_DrawLine(x1, y1, x2, y2)
        End Function
        Public Function DrawRect(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double) As Int32
            Return DC_DrawRect(x1, y1, x2, y2)
        End Function
        Public Function DrawRoundRect(ByVal x1 As Double, ByVal y1 As Double, ByVal x2 As Double, ByVal y2 As Double, ByVal width As Double, ByVal height As Double) As Int32
            Return DC_DrawRoundRect(x1, y1, x2, y2, width, height)
        End Function
        Public Function DrawCircle(ByVal x As Double, ByVal y As Double, ByVal radius As Double) As Int32
            Return DC_DrawCircle(x, y, radius)
        End Function
        Public Function GetPictureSize(ByVal path As String, ByRef width As Double, ByRef height As Double) As Int32
            width = 0.0
            height = 0.0
            Return DC_GetPictureSize(path, width, height)
        End Function
        Public Function PrintPicture(ByVal path As String, ByVal x As Double, ByVal y As Double, ByVal width As Double, ByVal height As Double) As Int32
            Return DC_PrintPicture(path, x, y, width, height)
        End Function

        Public Function Draw2OF5(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal checksum As Boolean, ByVal add_text As Boolean, ByVal thickness As Integer) As Int32
            Return DC_Draw2of5(str, pos_x, pos_y, checksum, add_text, thickness)
        End Function
        Public Function DrawCodaBar(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Integer) As Int32
            Return DC_DrawCodaBar(str, pos_x, pos_y, add_text, thickness)
        End Function
        Public Function DrawCode128(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal advance As Boolean, ByVal thickness As Integer) As Int32
            Return DC_DrawCode128(str, pos_x, pos_y, add_text, advance, thickness)
        End Function
        Public Function DrawCode39(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal checksum As Boolean, ByVal add_text As Boolean, ByVal thickness As Integer) As Int32
            Return DC_DrawCode39(str, pos_x, pos_y, checksum, add_text, thickness)
        End Function
        Public Function DrawCode93(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Integer) As Int32
            Return DC_DrawCode93(str, pos_x, pos_y, add_text, thickness)
        End Function
        Public Function DrawEAN13(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Integer) As Int32
            Return DC_DrawEAN13(str, pos_x, pos_y, add_text, thickness)
        End Function
        Public Function DrawEAN8(ByVal str As String, ByVal add_str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Integer) As Int32
            Return DC_DrawEAN8(str, pos_x, pos_y, add_text, thickness)
        End Function
        Public Function DrawUPCA(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Integer) As Int32
            Return DC_DrawUPCA(str, pos_x, pos_y, add_text, thickness)
        End Function
        Public Function DrawUPCE(ByVal str As String, ByVal pos_x As Double, ByVal pos_y As Double, ByVal add_text As Boolean, ByVal thickness As Integer) As Int32
            Return DC_DrawUPCE(str, pos_x, pos_y, add_text, thickness)
        End Function
    End Class

    Public Class PrintASCII
        <DllImport("CoreDll.dll", EntryPoint:="LoadLibrary", SetLastError:=True)> _
        Private Shared Function LoadLibrary(ByVal lpFileName As String) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="ASCII_OpenPrinter")> _
        Private Shared Function ASCII_OpenPrinter(ByVal portnum As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="ASCII_ClosePrinter")> _
        Private Shared Function ASCII_ClosePrinter() As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="ASCII_SendString")> _
        Private Shared Function ASCII_SendString(ByVal str As String) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="ASCII_DirectData")> _
        Private Shared Function ASCII_DirectData(ByVal array As Byte(), ByVal size As Int32) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="ASCII_SelectPrinter")> _
        Private Shared Function ASCII_SelectPrinter(ByVal pt As PrinterType) As Int32
        End Function
        <DllImport("PrintDLL.dll", EntryPoint:="ASCII_SetComPortParam")> _
        Private Shared Function ASCII_SetComPortParam(ByVal cs As ComState) As Int32
        End Function
        Public Sub New()
            If LoadLibrary("PrintDLL.dll") = 0 Then
                Throw (New PrintCE_LoadLib_Exception)
            End If
        End Sub
        Public Function OpenPrinter(ByVal portnum As Int32) As Int32
            Return ASCII_OpenPrinter(portnum)
        End Function
        Public Function ClosePrinter() As Int32
            Return ASCII_ClosePrinter()
        End Function
        Public Function SendString(ByVal str As String) As Int32
            Return ASCII_SendString(str)
        End Function
        Public Function DirectData(ByVal bytes As Byte(), ByVal count As Integer) As Int32
            Return ASCII_DirectData(bytes, count)
        End Function
        Public Function SelectPrinter(ByVal pt As PrinterType) As Int32
            Return ASCII_SelectPrinter(pt)
        End Function
        Public Function SetComPortParam(ByVal cs As ComState) As Int32
            ASCII_SetComPortParam(cs)
        End Function
    End Class
End Namespace