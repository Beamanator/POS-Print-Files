Imports example_vb.PrintCENET

Public Class Form1

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click

        Dim print As PrintDC

        Try
            print = New PrintDC
        Catch x As Exception
            MessageBox.Show(x.Message, "Error")
            Return
        End Try

        Dim pf As PrintInfo
        pf.paperHeight = 600
        pf.paperWidth = 0
        pf.pcs = IntPtr.Zero
        pf.port = 7
        pf.printOrient = PrintOrientation.SPRT_PO_PORTRAIT
        pf.printType = PrinterType.SPRT_PT_TIII_TIV
        pf.bRoll = 1

        If print.PrinterSet(pf) = 0 Then
            MessageBox.Show("DC_PrinterSet failed")
            Return
        End If

        ' Driver flow
        If print.StartDoc() = 0 Then
            MessageBox.Show("DC_StartDoc error")
            Return
        End If
        If print.StartPage() = 0 Then
            MessageBox.Show("DC_StartPage error")
            Return
        End If
        print.MapMode = MapMode.SPRT_MM_MM

        Dim fontProperty As FontProperty
        fontProperty = New FontProperty

        fontProperty.bDefault = False
        fontProperty.bItalic = True
        fontProperty.bStrikeout = False
        fontProperty.bUnderLine = True
        fontProperty.iCharSet = 0
        fontProperty.nWidth = 15
        fontProperty.nHeight = 36
        fontProperty.iWeight = 900
        print.SetFont(fontProperty)

        Dim str As String
        str = "SPRT"
        print.PrintText(str, 0, 0)
        print.SetFontName("Tahoma")
        fontProperty.bDefault = True
        print.SetFont(fontProperty)
        str = "Beijing Spirit Technology Development Co., Ltd. is one of the leading manufactured of mini-printer in China, which head-quartered in the Shangdi Information Industrial Park of Beijing"
        print.PrintTextBlock(str, 0, 5, 48, 50, 16)

        str = "A0253B"
        print.DrawCodaBar(str, 0, 30, True, 1)

        Dim wpic As Double
        Dim hpic As Double
        wpic = 0.0
        hpic = 0.0
        str = "\Temp\tiii.bmp"
        If print.GetPictureSize(str, wpic, hpic) = 1 Then
            print.PrintPicture(str, 5.0, 50.0, wpic, hpic)
        End If
        str = "TIII pic"
        print.PrintText(str, wpic + 5.0, 43.0 + hpic)
        print.EndDoc()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click

        Dim print As PrintASCII
        Try
            print = New PrintASCII
        Catch x As Exception
            MessageBox.Show(x.Message, "Error")
            Return
        End Try

        print.OpenPrinter(7)
        print.SendString("Beijing Spirit Technology Development Co., Ltd. is one of the leading manufactured of mini-printer in China, which head-quartered in the Shangdi Information Industrial Park of Beijing")

        Dim bytes As Byte() = {&HD&, &HD&, &H77&, &H77&, &H77&, &H2E&, &H73&, &H70&, &H72&, &H69&, &H6E&, &H74&, &H65&, &H72&, &H2E&, &H63&, &H6F&, &H6D&, &H2E&, &H63&, &H6E&, &HD&}
        print.DirectData(bytes, bytes.Length)
        print.ClosePrinter()
    End Sub

End Class
