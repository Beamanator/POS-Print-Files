using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PrintCENET;
using System.IO;

namespace example_cs
{
    public partial class Form1 : Form
    {
        
        private int COMnum = 8;
        string dirPath = null;

        public Form1()
        {
            InitializeComponent();
            this.comboBox1.Text = "COM8";
            dirPath = GetAppRunPath();
        }

        PrintDC print;
        PrinterInfo pf;
        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                print = new PrintDC();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Error");
                return;
            }

            pf.paperHeight = 1000;
            pf.paperWidth = 0;
            pf.pcs = IntPtr.Zero;
            pf.port = COMnum;
            //pf.printOrient = PrintOrientation.PRINT_PO_PORTRAIT;
            pf.printOrient = PrintOrientation.PRINT_PO_LANDSCAPE;
            pf.printType = PrinterType.PRINT_PT_TIII_TIV;
            //pf.printType = PrinterType.PRINT_PT_T8;
            pf.bRoll = 1;


            if (print.PrinterSet(pf) == 0)
            {
                MessageBox.Show("DC_PrinterSet failed");
                return;
            }

            // Driver flow
            if (print.StartDoc() == 0)
            {
                MessageBox.Show("DC_StartDoc error");
                return;
            }
            if (print.StartPage() == 0)
            {
                MessageBox.Show("DC_StartPage error");
                return;
            }

            //double x, y, width, height;
            //print.MapMode = MapMode.PRINT_MM_MM;
            print.MapMode = MapMode.PRINT_MM_DOT;

            FontProperty fontProperty = new FontProperty();

            fontProperty.bDefault = false;
            fontProperty.bItalic = true;
            fontProperty.bStrikeout = false;
            fontProperty.bUnderLine = true;
            fontProperty.iCharSet = 0;
            fontProperty.nWidth = 15;
            fontProperty.nHeight = 36;
            fontProperty.iWeight = 900;
            print.SetFont(fontProperty);

            string str;
            str = "PRINT";
            print.PrintText(str, 0, 0);

            fontProperty.bDefault = true;
            print.SetFont(fontProperty);
            //print.SetFontName("Tahoma");
            str = "Do you know what I like? Summer vacation. I like it because I can go outside to play. If it rains, I can stay inside and play checkers. And this summer my family may go to Beijing, because we have not been there yet.";
            //print.PrintTextBlock(str,
            //                0, 5,
            //                48, 20, 16);
            print.PrintTextBlock(str,
                            0, 40,
                            384, 160, 16);


            str = "A0253B";
            print.DrawCodaBar(str, 0, 200, true, 1);

            double wpic, hpic;
            wpic = 0.0;
            hpic = 0.0;            

            str = dirPath + "\\goodwork.bmp";
            if (print.GetPictureSize(str, ref wpic, ref hpic) == 1)
            {
                print.PrintPicture(str, 40, 360, (int)wpic, (int)hpic);
            }

            int h = (int)hpic;
            str = "goodwork.bmp";
            print.PrintText(str, 20, 340 + h);              

            print.EndDoc();

            //print.FreeLib();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PrintASCII print;
            try
            {
                print = new PrintASCII();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Error");
                return;
            }
            print.OpenPrinter(COMnum);
            print.SendString("Do you know what I like? Summer vacation. I like it because I can go outside to play. If it rains, I can stay inside and play checkers. And this summer my family may go to Beijing, because we have not been there yet.");

            byte[] bytes = { 0x0d, 0x0d, 0x0d, 0x77, 0x77, 0x77, 0x2e, 0x70, 0x72, 0x69, 0x6e, 0x74, 0x2e, 0x63, 0x6f, 0x6d, 0x2e, 0x63, 0x6e, 0x0d };
            print.DirectData(bytes, bytes.Length);
            print.ClosePrinter();
        }

        //Retrieve printer status
        private void button3_Click(object sender, EventArgs e)
        {
            byte sbt1,sbt2,sbt3,sbt4;
            string sStr1 = "";
            string sStr2 = "";
            string sStr3 = "";
            string sStr4 = "";


            PrintASCII print;

            try
            {
                print = new PrintASCII();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Error");
                return;
            }

            byte[] bytes = new byte[2];

            print.OpenPrinter(COMnum);

            if (print.GetPrinterStatus(bytes, 1) == 1)
            {
                sbt1 = bytes[0];
                if ((sbt1 & 0x08) != 0)
                    sStr1 = "/�ѻ�/";   //offline
                else sStr1 = "/����/";  //online 

                if ((sbt1 & 0x04) == 0)
                    sStr1 += "/Ǯ���ź�Ϊ��/";  //cash-drawer signal is low
                else sStr1 += "/Ǯ���ź�Ϊ��/"; //cash-drawer signal is high
            }
            bytes[0] = 0;
            if (print.GetPrinterStatus(bytes, 2) == 1)
            {
                sbt2 = bytes[0];
                if ((sbt2 & 0x40) != 0)
                    sStr2 = "/�д������/";     //error occurred
                else sStr2 = "/�޴������/";    //no error
                if ((sbt2 & 0x20) != 0)
                    sStr2 += "/ȱֽͣ��/";      //out of paper,halt
                else sStr2 += "/δȱֽͣ��/";   //paper is ready
                if ((sbt2 & 0x08) != 0)
                    sStr2 += "/������ֽ��/";    //feed key is pressed 
                else sStr2 += "/δ������ֽ��/"; //feed key isn't pressed
                if ((sbt2 & 0x04) != 0)
                    sStr2 += "/�ϸǿ�/";        //cover opened
                else sStr2 += "/�ϸǹ�/";       //cover closed
            }
            bytes[0] = 0;
            if (print.GetPrinterStatus(bytes, 3) == 1)
            {
                sbt3 = bytes[0];
                if ((sbt3 & 0x40) != 0)
                    sStr3 = "/���Զ��ָ�����/";     //automatically recoverable error occurred
                else sStr3 = "/���Զ��ָ�����/";    //no automatically recoverable error
                if ((sbt3 & 0x20) != 0)
                    sStr3 += "/�в��ɻָ�����/";    //unrecoverable error occurred
                else sStr3 += "/�޲��ɻָ�����/";   //no unrecoverable error
                if ((sbt3 & 0x08) != 0)
                    sStr3 += "/�е�����/";          //cutter error
                else sStr3 += "/�е��޴���/";       //cutter is normal
            }
            bytes[0] = 0;
            if (print.GetPrinterStatus(bytes, 4) == 1)
            {
                sbt4 = bytes[0];
                if ((sbt4 & 0x40) != 0)
                    sStr4 = "/ֽ��/";   //paper is over
                else sStr4 = "/��ֽ/";  //paper is normal
                //if ((sbt4 & 0x08) != 0)
                //    sStr4 += "/ֽ����/";      //paper will be over
                //else sStr4 += "/���㹻��ֽ/"; //paper is enough
            }

            print.ClosePrinter();

            label1.Text = sStr1;
            label2.Text = sStr2;
            label3.Text = sStr3;
            label4.Text = sStr4;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            COMnum = comboBox1.SelectedIndex;
            COMnum++;
        }

        public static String GetAppRunPath()
        {
            return System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetName().CodeBase);
        }

    }
}