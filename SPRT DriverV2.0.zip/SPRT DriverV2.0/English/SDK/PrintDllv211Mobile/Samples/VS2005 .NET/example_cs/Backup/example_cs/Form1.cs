using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using PrintCENET;

namespace example_cs
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            PrintDC print;
            try
            {
                print = new PrintDC();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Error");
                return;
            }            
            PrinterInfo pf;
            pf.paperHeight = 600;
            pf.paperWidth = 0;
            pf.pcs = IntPtr.Zero;
            pf.port = 8;
            pf.printOrient = PrintOrientation.SPRT_PO_PORTRAIT;
            pf.printType = PrinterType.SPRT_PT_TIII_TIV;
            pf.bRoll = 1;


            if (print.PrinterSet(pf) == 0)
	        {
		        MessageBox.Show("DC_PrinterSet failed");
		        return;
	        }
            // Driver flow
            if (print.StartDoc() == 0)
            {
                MessageBox.Show("DC_StartDoc error");
                return;
            }
            if (print.StartPage() == 0)
            {
                MessageBox.Show("DC_StartPage error");
                return;
            }

            //double x, y, width, height;
            print.MapMode = MapMode.SPRT_MM_MM;

            FontProperty fontProperty = new FontProperty();

            fontProperty.bDefault = false;
            fontProperty.bItalic = true;
            fontProperty.bStrikeout = false;
            fontProperty.bUnderLine = true;
            fontProperty.iCharSet = 0;
            fontProperty.nWidth = 15;
            fontProperty.nHeight = 36;
            fontProperty.iWeight = 900;
            print.SetFont(fontProperty);

            string str;
            str = "SPRT";
            print.PrintText(str, 0, 0);

            fontProperty.bDefault = true;
            print.SetFont(fontProperty);
            print.SetFontName("Tahoma");
            str = "Beijing Spirit Technology Development Co., Ltd. is one of the leading manufactured of mini-printer in China, which head-quartered in the Shangdi Information Industrial Park of Beijing";
            print.PrintTextBlock(str,
                            0, 5,
                            48, 50, 16);

            str = "A0253B";
            print.DrawCodaBar(str, 0, 30, true, 1);

            double wpic, hpic;
            wpic = 0.0;
            hpic = 0.0;
            str = "\\Temp\\tiii.bmp";
            if (print.GetPictureSize(str, ref wpic, ref hpic) == 1)
            {
                print.PrintPicture(str, 5, 50, wpic, hpic);
            }
            str = "TIII pic";
            print.PrintText(str, wpic + 5, 43 + hpic);
            print.EndDoc();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            PrintASCII print;
            try
            {
                print = new PrintASCII();
            }
            catch (Exception x)
            {
                MessageBox.Show(x.Message, "Error");
                return;
            } 
            print.OpenPrinter(7);
            print.SendString("Beijing Spirit Technology Development Co., Ltd. is one of the leading manufactured of mini-printer in China, which head-quartered in the Shangdi Information Industrial Park of Beijing");

            byte[] bytes = { 0x0d, 0x0d, 0x0d, 0x77, 0x77, 0x77, 0x2e, 0x73, 0x70, 0x72, 0x69, 0x6e, 0x74, 0x65, 0x72, 0x2e, 0x63, 0x6f, 0x6d, 0x2e, 0x63, 0x6e, 0x0d };
            print.DirectData(bytes, bytes.Length);
            print.ClosePrinter();
        }
    }
}