using System;
using System.Runtime.InteropServices;
using System.Drawing;

namespace PrintCENET
{
    public enum PrinterType
	{
        PRINT_PT_TIII_TIV = 0,
        PRINT_PT_T5,
        PRINT_PT_T8
	};

    public enum PrintOrientation
	{
        PRINT_PO_PORTRAIT,
        PRINT_PO_LANDSCAPE
	};

    public enum ConnectedStatus
	{
        PRINT_CS_NOTINITED,
        PRINT_CS_NORMAL,
        PRINT_CS_IDLE,
        PRINT_CS_BUSY
	};

    public enum PrinterStatus
	{
        PRINT_PS_NORMAL,
        PRINT_PS_OUTPAPER,
        PRINT_PS_ERROR
	};

    public enum MapMode
	{
        PRINT_MM_DOT,
        PRINT_MM_INCH,
        PRINT_MM_MM
	};

    public struct ComState
	{
        public int dwBaudRate;
        public byte Parity;
        public byte StopBits;
	};

    public struct PrinterInfo
    {
        public PrinterType printType;
        public PrintOrientation printOrient;
        public double paperWidth;
        public double paperHeight;
        public int bRoll;
        public int port;
        public IntPtr pcs;
    };

    public struct FontProperty
    { 
        public bool bDefault;
	    public bool bUnderLine;
	    public bool bItalic;
	    public bool bStrikeout;
	    public int nWidth;
	    public int nHeight;
	    public int iCharSet;
	    public int iWeight;
    };
    

	public class PrintCE_LoadLib_Exception : System.Exception
	{
		public override string Message
		{
			get
			{
				return "PrintDLL.dll not found";
			}
		}											 
	}
      
    
	/// <summary>
	/// Summary description for PrintDLL.
	/// </summary>
    public class PrintDC
    {
        int hInst;

        public FontProperty fontProperty;

        public PrintDC()
        {
            hInst = LoadLibrary("PrintDLL.dll");


            if (hInst == 0)
                throw (new PrintCE_LoadLib_Exception());
        }

        [DllImport("CoreDll.dll", EntryPoint = "LoadLibrary")]
        private static extern int LoadLibrary(string lpFileName);

        [DllImport("CoreDll.dll", EntryPoint = "FreeLibrary")]
        public static extern int FreeLibrary(int handle);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_StartDoc")]
        private static extern int DC_StartDoc();

        [DllImport("PrintDLL.dll", EntryPoint = "DC_StartPage")]
        private static extern int DC_StartPage();

        [DllImport("PrintDLL.dll", EntryPoint = "DC_EndDoc")]
        private static extern int DC_EndDoc();

        [DllImport("PrintDLL.dll", EntryPoint = "DC_PrinterSet")]
        private static extern int DC_PrinterSet(PrinterInfo pi);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_GetConnectedStatus")]
        private static extern int DC_GetConnectedStatus();

        //[DllImport("PrintDLL.dll", EntryPoint = "DC_GetPrinterStatus")]
        //private static extern int DC_GetPrinterStatus(Byte[] sBuf, int n);        

        [DllImport("PrintDLL.dll", EntryPoint = "DC_GetDevCaps")]
        private static extern int DC_GetDevCaps(int devcap);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_GetMapMode")]
        private static extern int DC_GetMapMode();

        [DllImport("PrintDLL.dll", EntryPoint = "DC_SetMapMode")]
        private static extern int DC_SetMapMode(MapMode mm);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_SetFont")]
        private static extern int DC_SetFont(FontProperty fp);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_SetFontName")]
        private static extern int DC_SetFontName(string str);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_PrintText")]
        private static extern int DC_PrintText(string str, double pos_x, double pos_y);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_PrintTextBlock")]
        private static extern int DC_PrintTextBlock(string str, double pos_x, double pos_y, double wdith, double height, int iformat);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_SetBorderMode")]
        private static extern int DC_SetBorderMode(bool bfill);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_SetFillMode")]
        private static extern int DC_SetFillMode(bool bfill);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_GetLineWidth")]
        private static extern int DC_GetLineWidth(ref double width);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_SetLineWidth")]
        private static extern int DC_SetLineWidth(double width);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawEllips")]
        private static extern int DC_DrawEllips(double x1, double x2, double y1, double y2);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawLine")]
        private static extern int DC_DrawLine(double x1, double y1, double x2, double y2);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawRect")]
        private static extern int DC_DrawRect(double x1, double y1, double x2, double y2);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawRoundRect")]
        private static extern int DC_DrawRoundRect(double x1, double y1, double x2, double y2, double width, double height);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawCircle")]
        private static extern int DC_DrawCircle(double x, double y, double radius);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_GetPictureSize")]
        private static extern int DC_GetPictureSize(string filepath, ref double width, ref double height);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_PrintPicture")]
        private static extern int DC_PrintPicture(string filepath, double x, double y, double width, double height);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_SetBarcodeHeight")]
        private static extern int DC_SetBarcodeHeight(double height);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_Draw2of5")]
        private static extern int DC_Draw2of5(string str, double pos_x, double pos_y, bool checksum, bool add_text, int thickness);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawCodaBar")]
        private static extern int DC_DrawCodaBar(string str, double pos_x, double pos_y, bool add_text, int thickness);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawCode128")]
        private static extern int DC_DrawCode128(string str, double pos_x, double pos_y, bool add_text, bool advance, int thickness);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawCode39")]
        private static extern int DC_DrawCode39(string str, double pos_x, double pos_y, bool checksum, bool add_text, int thickness);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawCode93")]
        private static extern int DC_DrawCode93(string str, double pos_x, double pos_y, bool add_text, int thickness);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawUPCA")]
        private static extern int DC_DrawUPCA(string str, double pos_x, double pos_y, bool add_text, int thickness);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawUPCE")]
        private static extern int DC_DrawUPCE(string str, double pos_x, double pos_y, bool add_text, int thickness);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawEAN13")]
        private static extern int DC_DrawEAN13(string str, double pos_x, double pos_y, bool add_text, int thickness);

        [DllImport("PrintDLL.dll", EntryPoint = "DC_DrawEAN8")]
        private static extern int DC_DrawEAN8(string str, double pos_x, double pos_y, bool add_text, int thickness);

        public ConnectedStatus ConnectedStatus
        {
            get
            {
                return (ConnectedStatus)DC_GetConnectedStatus();
            }
        }

        public MapMode MapMode
        {
            get
            {
                return (MapMode)DC_GetMapMode();
            
            }
            set
            {
                DC_SetMapMode(value);
            }
        }

        public bool BorderMode
        {
            set
            {
                DC_SetBorderMode((bool)value);
            }
        }

        public bool FillMode
        {
            set
            {
                DC_SetFillMode((bool)value);
            }
        }

        public double LineWidth
        {
            get
            {
                double width = 0;
                DC_GetLineWidth(ref width);
                return width;
            }
            set
            {
                DC_SetLineWidth(value);
            }
        }

        public double BarcodeHeight
        {
            set
            {
                DC_SetBarcodeHeight(value);
            }
        }

        public int StartDoc()
        {
            return DC_StartDoc();
        }

        public int StartPage()
        {
            return DC_StartPage();
        }

        public int EndDoc()
        {
            return DC_EndDoc();
        }

        public int PrinterSet(PrinterInfo pi)
        {
            return DC_PrinterSet(pi);
        }

        public int GetDevCaps(int iVal)
        {
            return DC_GetDevCaps(iVal);
        }

        //public int GetPrinterStatus(Byte[] stbuf, int ity)
        //{
        //    return DC_GetPrinterStatus(stbuf,ity);
        //}

        public int SetFont(FontProperty fp)
        {
            return DC_SetFont(fp);
        }

        public int SetFontName(string str)
        {
            return DC_SetFontName(str);
        }

        public int PrintText(string str, double pos_x, double pos_y)
        {
            return DC_PrintText(str, pos_x, pos_y);
        }

        public int PrintTextBlock(string str, double pos_x, double pos_y, double width, double height, int iFormat)
        {
            return DC_PrintTextBlock(str, pos_x, pos_y, width, height, iFormat);
        }

        public int DrawEllips(double x1, double y1, double x2, double y2)
        {
            return DC_DrawEllips(x1, y1, x2, y2);
        }

        public int DrawLine(double x1, double y1, double x2, double y2)
        {
            return DC_DrawLine(x1, y1, x2, y2);
        }

        public int DrawRect(double x1, double y1, double x2, double y2)
        {
            return DC_DrawRect(x1, y1, x2, y2);
        }

        public int DrawRoundRect(double x1, double y1, double x2, double y2, double width, double height)
        {
            return DC_DrawRoundRect(x1, y1, x2, y2, width, height);
        }

        public int DrawCircle(double x, double y, double radius)
        {
            return DC_DrawCircle(x, y, radius);
        }

        public int GetPictureSize(string filepath, ref double width, ref double height)
        {
            return DC_GetPictureSize(filepath,ref width, ref height);
        }

        public int PrintPicture(string filepath, double x, double y, double width, double height)
        {
            return DC_PrintPicture(filepath, x, y, width, height);
        }

        public int Draw2of5(string str, double pos_x, double pos_y, bool checksum, bool add_text, int thickness)
        {
            return DC_Draw2of5(str, pos_x, pos_y, checksum, add_text, thickness);
        }

        public int DrawCodaBar(string str, double pos_x, double pos_y, bool add_text, int thickness)
        {
            return DC_DrawCodaBar(str, pos_x, pos_y, add_text, thickness);
        }

        public int DrawCode128(string str, double pos_x, double pos_y, bool add_text, bool advance, int thickness)
        {
            return DC_DrawCode128(str, pos_x, pos_y, add_text, advance, thickness);
        }

        public int DrawCode39(string str, double pos_x, double pos_y, bool checksum, bool add_text, int thickness)
        {
            return DC_DrawCode39(str, pos_x, pos_y, checksum, add_text, thickness);
        }

        public int DrawCode93(string str, double pos_x, double pos_y, bool add_text, int thickness)
        {
            return DC_DrawCode93(str, pos_x, pos_y, add_text, thickness);
        }

        public int DrawUPCA(string str, double pos_x, double pos_y, bool add_text, int thickness)
        {
            return DC_DrawUPCA(str, pos_x, pos_y, add_text, thickness);
        }

        public int DrawUPCE(string str, double pos_x, double pos_y, bool add_text, int thickness)
        {
            return DC_DrawUPCE(str, pos_x, pos_y, add_text, thickness);
        }

        public int DrawEAN13(string str, double pos_x, double pos_y, bool add_text, int thickness)
        {
            return DC_DrawEAN13(str, pos_x, pos_y, add_text, thickness);
        }

        public int DrawEAN8(string str, double pos_x, double pos_y, bool add_text, int thickness)
        {
            return DC_DrawEAN8(str, pos_x, pos_y, add_text, thickness);
        }

        public int FreeLib()
        {
            return FreeLibrary(hInst);
        }
    }

	/// <summary>
	/// Summary description for PrintDLL.
	/// </summary>
    public class PrintASCII
    {
        public PrintASCII()
        {
            if (LoadLibrary("PrintDLL.dll") == 0)
                throw (new PrintCE_LoadLib_Exception());
        }

        [DllImport("CoreDll.dll", EntryPoint = "LoadLibrary")]
        private static extern int LoadLibrary(string lpFileName);

        [DllImport("PrintDLL.dll", EntryPoint = "ASCII_OpenPrinter")]
        private static extern int ASCII_OpenPrinter(int portnum);

        [DllImport("PrintDLL.dll", EntryPoint = "ASCII_ClosePrinter")]
        private static extern int ASCII_ClosePrinter();

        [DllImport("PrintDLL.dll", EntryPoint = "ASCII_SendString")]
        private static extern int ASCII_SendString(string str);

        [DllImport("PrintDLL.dll", EntryPoint = "ASCII_DirectData")]
        private static extern int ASCII_DirectData(byte[] bytes, int count);

        [DllImport("PrintDLL.dll", EntryPoint = "ASCII_SelectPrinter")]
        private static extern int ASCII_SelectPrinter(PrinterType pt);

        [DllImport("PrintDLL.dll", EntryPoint = "ASCII_SetComPortParam")]
        private static extern int ASCII_SetComPortParam(ComState cs);

        [DllImport("PrintDLL.dll", EntryPoint = "ASCII_GetPrinterStatus")]
        private static extern int ASCII_GetPrinterStatus(byte[] StusBuf, int n);

        public int OpenPrinter(int portnum)
        {
            return ASCII_OpenPrinter(portnum);
        }

        public int ClosePrinter()
        {
            return ASCII_ClosePrinter();
        }

        public int SendString(string str)
        {
            return ASCII_SendString(str);
        }

        public int DirectData(byte[] bytes, int length)
        {
            return ASCII_DirectData(bytes, length);
        }

        public int SelectPrinter(PrinterType pt)
        {
            return ASCII_SelectPrinter(pt);
        }

        public int SetComPortParam(ComState cs)
        {
            return ASCII_SetComPortParam(cs);
        }

        public int GetPrinterStatus(byte[] StusBuf, int n)
        {
            return ASCII_GetPrinterStatus(StusBuf, n);
        }
        
    }
}
