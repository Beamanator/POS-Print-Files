Public Class Form1
    '�����򿪶˿ں���
    Declare Unicode Function OpenPort Lib "..\\..\\..\\..\\sdk\\POS_SDK.dll" Alias "POS_Port_OpenW" (ByVal lpName As String, ByVal iPort As Integer, ByVal bFile As Boolean, ByVal szFilePath As String) As Integer
    '�����������ݺ���
    Declare Unicode Function WritePort Lib "..\\..\\..\\..\\sdk\\POS_SDK.dll" Alias "POS_Output_PrintStringW" (ByVal iPrinterID As Integer, ByVal lpStr As String) As Integer
    '���͵��ֽ�ָ��
    Declare Ansi Function WriteCommand Lib "..\\..\\..\\..\\sdk\\POS_SDK.dll" Alias "POS_Output_PrintData" (ByVal iPrinterID As Integer, ByVal lpStr As Byte(), ByVal length As Integer) As Integer
    '��ӡ�ַ���
    Declare Ansi Function WirteString Lib "..\\..\\..\\..\\sdk\\POS_SDK.dll" Alias "POS_Output_PrintStringA" (ByVal iPrinterID As Integer, ByVal lpStr As String) As Integer
    '�����رն˿ں���
    Declare Auto Function ClosePort Lib "..\\..\\..\\..\\sdk\\POS_SDK.dll" Alias "POS_Port_Close" (ByVal iPrinterID As Integer) As Integer

    Declare Auto Function SendBarcode Lib "..\\..\\..\\..\\sdk\\POS_SDK.dll" Alias "POS_Output_PrintBarcodeW" (ByVal iPrinterID As Integer, ByVal iType As Integer, ByVal iwidth As Integer, ByVal iheigth As Integer, ByVal ihri As Integer, ByVal lpStr As String) As Long

    Private iType As Integer
    Private OpenResult As Integer
    Private Const POS_PT_COM As Integer = 1000
    Private Const POS_PT_LPT As Integer = 1001
    Private Const POS_PT_USB As Integer = 1002
    Private Const POS_PT_NET As Integer = 1003
    'printer state
    Private Const POS_PS_NORMAL As Integer = 3001
    Private Const POS_PS_PAPEROUT As Integer = 3002
    Private Const POS_PS_HEAT As Integer = 3003
    Private Const POS_PS_DOOROPEN As Integer = 3004
    Private Const POS_PS_BUFFEROUT As Integer = 3005
    Private Const POS_PS_CUT As Integer = 3006

    'barcode type
    Private Const POS_BT_UPCA As Integer = 4001
    Private Const POS_BT_UPCE As Integer = 4002
    Private Const POS_BT_JAN13 As Integer = 4003
    Private Const POS_BT_JAN8 As Integer = 4004
    Private Const POS_BT_CODE39 As Integer = 4005
    Private Const POS_BT_ITF As Integer = 4006
    Private Const POS_BT_CODABAR As Integer = 4007
    Private Const POS_BT_CODE93 As Integer = 4008
    Private Const POS_BT_CODE128 As Integer = 4009

    'HRI type
    Private Const POS_HT_NONE As Integer = 4011
    Private Const POS_HT_UP As Integer = 4012
    Private Const POS_HT_DOWN As Integer = 4013
    Private Const POS_HT_BOTH As Integer = 4014

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        RadioButton1.Checked = True
        TextBox1.Text = "COM1:9600,N,8,1"
        TextBox2.Text = "Hi, thank you for choose SPRT, We will get your the best experience!"
        TextBox3.Text = "..\..\..\..\bmp\goodwork.bmp"
    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton1.CheckedChanged
        iType = POS_PT_COM
        TextBox1.Text = "COM1:9600,N,8,1"
    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton2.CheckedChanged
        iType = POS_PT_LPT
        TextBox1.Text = "LPT1:"
    End Sub

    Private Sub RadioButton3_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton3.CheckedChanged
        iType = POS_PT_USB
        TextBox1.Text = "SP-USB1"
    End Sub

    Private Sub RadioButton4_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RadioButton4.CheckedChanged
        iType = POS_PT_NET
        TextBox1.Text = "192.168.1.114"
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        OpenResult = OpenPort(TextBox1.Text, iType, False, vbNullString)
        If OpenResult <> 0 Then
            WirteString(OpenResult, TextBox2.Text)
            ClosePort(OpenResult)
        Else
            MsgBox("error in open port")
        End If
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click

    End Sub
End Class
