// VCDlg.cpp : implementation file
//

#include "stdafx.h"
#include "VC.h"
#include "VCDlg.h"
#include "LoadDll.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


#define POS_PT_COM			1000L
#define POS_PT_LPT			1001L
#define POS_PT_USB			1002L
#define POS_PT_NET			1003L

// printer state
#define POS_PS_NORMAL			3001L 	// ״̬����
#define POS_PS_PAPEROUT			3002L 	//��ӡ��ȱֽ
#define	POS_PS_HEAT				3003L 	//��ͷ����
#define POS_PS_DOOROPEN			3004L 	//ֽ���ſ�
#define POS_PS_BUFFEROUT		3005L 	//��������
#define POS_PS_CUT				3006L 	//�е�δ��λ

// barcode type
#define POS_BT_UPCA			4001L
#define POS_BT_UPCE			4002L
#define POS_BT_JAN13		4003L
#define POS_BT_JAN8			4004L
#define POS_BT_CODE39		4005L
#define POS_BT_ITF			4006L
#define POS_BT_CODABAR		4007L
#define POS_BT_CODE93		4008L
#define POS_BT_CODE128		4009L

// HRI type
#define POS_HT_NONE			4011L
#define POS_HT_UP			4012L
#define POS_HT_DOWN			4013L
#define POS_HT_BOTH			4014L

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVCDlg dialog

CVCDlg::CVCDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CVCDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CVCDlg)
	m_text = _T("");
	m_bmpPath = _T("");
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CVCDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CVCDlg)
	DDX_Control(pDX, IDC_EDIT1, m_config);
	DDX_Text(pDX, IDC_EDIT2, m_text);
	DDX_Text(pDX, IDC_EDIT3, m_bmpPath);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CVCDlg, CDialog)
	//{{AFX_MSG_MAP(CVCDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_RADIO1, OnRadio1)
	ON_BN_CLICKED(IDC_RADIO2, OnRadio2)
	ON_BN_CLICKED(IDC_RADIO3, OnRadio3)
	ON_BN_CLICKED(IDC_RADIO4, OnRadio4)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDOK, &CVCDlg::OnBnClickedOk)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CVCDlg message handlers

BOOL CVCDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_com = (CButton *)GetDlgItem(IDC_RADIO1);
	m_para = (CButton *)GetDlgItem(IDC_RADIO2);
	m_usb = (CButton *)GetDlgItem(IDC_RADIO3);
	m_net = (CButton *)GetDlgItem(IDC_RADIO4);

	m_com->SetCheck(1);
	m_iPortTpye = POS_PT_COM;
	m_config.SetWindowText("COM1:9600,N,8,1");
	m_text = "Hi, thank you for choose our printer, We will get your the best experience!\r\n��л��ѡ�������ǵĴ�ӡ��\r\n\r\n";
	m_bmpPath = "..\\..\\bmp\\goodwork.bmp";
	UpdateData(false);

	if(!LoadSDKLibrary())
	{
		MessageBox("Error load dll file, please check!");
	}
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CVCDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CVCDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CVCDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CVCDlg::OnRadio1() 
{
	// TODO: Add your control notification handler code here
	m_config.SetWindowText("COM1:9600,N,8,1");
	m_iPortTpye = POS_PT_COM;
}

void CVCDlg::OnRadio2() 
{
	// TODO: Add your control notification handler code here
	m_config.SetWindowText("LPT1:");
	m_iPortTpye = POS_PT_LPT;
}

void CVCDlg::OnRadio3() 
{
	// TODO: Add your control notification handler code here
	m_config.SetWindowText("SP-USB1");
	m_iPortTpye = POS_PT_USB;
}

void CVCDlg::OnRadio4() 
{
	// TODO: Add your control notification handler code here
	m_config.SetWindowText("192.168.1.114");
	m_iPortTpye = POS_PT_NET;
}

void CVCDlg::OnOK() 
{
	// TODO: Add extra validation here
	UpdateData();

	int m_a = 0;
	int sendNum = 0;
	int bl = 0;
	int iStates =POS_PS_NORMAL;
	CString strbuf;
	m_config.GetWindowText(strbuf);

	m_a = POS_Port_OpenA((LPSTR)(LPCSTR)strbuf, m_iPortTpye, FALSE, NULL);
	if(m_a == 0)
	{
		MessageBox("�˿ڴ�ʧ�ܣ���ȷ���˿��Ƿ�ռ�ã�", "����", MB_OK | MB_ICONERROR);
		return;
	}
//for(int i=0;i<15;i++)
//{
	sendNum = m_text.GetLength();
	char *szText = (LPSTR)(LPCSTR)m_text;
RESEND:
	bl = POS_Output_PrintData(m_a, szText, sendNum);
	sendNum -= bl;
	if(sendNum)
	{
		iStates = POS_Status_QueryStatus(m_a);
		switch(iStates)
		{
		case POS_PS_PAPEROUT:
			MessageBox("��ӡֽ��", "��ʾ", MB_ICONINFORMATION|MB_OK);
			Sleep(30000);
			goto RESEND;
			break;
		case POS_PS_HEAT:
			MessageBox("��ӡ����ͷ����", "��ʾ", MB_ICONINFORMATION|MB_OK);
			Sleep(30000);
			goto RESEND;
			break;
		case POS_PS_DOOROPEN:
			MessageBox("ֽ���Ŵ�", "��ʾ", MB_ICONINFORMATION|MB_OK);
			Sleep(30000);
			goto RESEND;
			break;
		case POS_PS_BUFFEROUT:
			MessageBox("��ӡ����������", "��ʾ", MB_ICONINFORMATION|MB_OK);
			Sleep(10000);
			goto RESEND;
			break;
		case POS_PS_CUT:
			MessageBox("��ӡ���е�δ��ȷ��λ", "��ʾ", MB_ICONINFORMATION|MB_OK);
			Sleep(30000);
			goto RESEND;
			break;
		default:
			break;
		}
		szText +=bl;
	}
	Sleep(100);
//}
	POS_Output_PrintBarcodeA(m_a, POS_BT_CODE39, 30, 50, POS_HT_DOWN, "123457890");

	POS_Output_PrintBarcodeA(m_a, 4100, 2, 6, 1, "www.sina.com-�й�");	
	POS_Output_PrintBarcodeA(m_a, 4101, 40, 40, 4, "www.sina.com-������_");	
	POS_Output_PrintBarcodeA(m_a, 4102, 2, 77, 4, "www.sina.com-ʯ��ׯ");
	

	POS_Output_PrintBmpDirectA(m_a, 0, m_bmpPath);

	POS_Control_CashDraw(m_a,1,100,100);

	POS_Control_CutPaper(m_a, 1, 0);
	POS_Port_Close(m_a);	
}

BOOL CVCDlg::DestroyWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	FreeSDKLibrary();

	return CDialog::DestroyWindow();
}

void CVCDlg::OnButton1() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE,"bmp",".bmp",OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,"λͼ�ļ�(*.BMP)|*.BMP||");	
	if(dlg.DoModal()==IDOK)
	{
		m_bmpPath = dlg.GetPathName();
	}
	UpdateData(false);
}

void CVCDlg::OnBnClickedOk()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	OnOK();
}
