﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Runtime.InteropServices;
using System.Threading;

namespace TestSDKCSharp
{
    public partial class Form1 : Form
    {
        bool Boldf = false;
        bool CdWidthf = false;
        bool CdHeight = false;
        bool CudrLine = false;

        bool Ecomprsf = false;
        bool EdWidthf = false;
        bool EdHeight = false;
        bool EudrLine = false;

        public Form1()
        {
            InitializeComponent();
        }

        private const Int32 POS_PT_COM = 1000;
        private const Int32 POS_PT_LPT = 1001;
        private const Int32 POS_PT_USB = 1002;
        private const Int32 POS_PT_NET = 1003;

        // printer state
        private const Int32 POS_PS_NORMAL = 3001;
        private const Int32 POS_PS_PAPEROUT = 3002;
        private const Int32 POS_PS_HEAT = 3003;
        private const Int32 POS_PS_DOOROPEN = 3004;
        private const Int32 POS_PS_BUFFEROUT = 3005;
        private const Int32 POS_PS_CUT = 3006;
        private const Int32 POS_PS_DRAWERHIGH = 3007;

        // barcode type
        private const Int32 POS_BT_UPCA = 4001;
        private const Int32 POS_BT_UPCE = 4002;
        private const Int32 POS_BT_JAN13 = 4003;
        private const Int32 POS_BT_JAN8 = 4004;
        private const Int32 POS_BT_CODE39 = 4005;
        private const Int32 POS_BT_ITF = 4006;
        private const Int32 POS_BT_CODABAR = 4007;
        private const Int32 POS_BT_CODE93 = 4008;
        private const Int32 POS_BT_CODE128 = 4009;

        // 2D barcode type
        private const Int32 POS_BT_PDF417 = 4100;       
        private const Int32 POS_BT_DATAMATRIX = 4101;
        private const Int32 POS_BT_QRCODE = 4102;

        // HRI type
        private const Int32 POS_HT_NONE = 4011;
        private const Int32 POS_HT_UP = 4012;
        private const Int32 POS_HT_DOWN = 4013;
        private const Int32 POS_HT_BOTH = 4014;

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Port_OpenA")]
        static extern Int32 Open(String lpName, Int32 iPort, bool bFile, String path);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi,EntryPoint = "POS_Output_PrintStringA")]
        static extern Int32 Send(Int32 printID, String strBuff);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Control_ReSet")]
        static extern long ReSet(Int32 printID);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Control_CutPaper")]
        static extern long CutPaper(Int32 printID, long type, long len);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Status_QueryStatus")]
        static extern Int32 QueryStatus(Int32 printID);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Status_RTQueryStatus")]
        static extern Int32 RTQueryStatus(Int32 printID);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Status_RTQueryTypeStatus")]
        static extern Int32 RTQueryTypeStatus(Int32 printID, Int32 n);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Output_PrintData")]
        static extern Int32 SendData(Int32 printID, byte[] strBuff, Int32 ilen);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Output_PrintBarcodeA")]
        static extern Int32 PrintBarcode(Int32 printID, Int32 type, Int32 width, Int32 height, Int32 hri, String strBuff);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Output_PrintBmpDirectA")]
        static extern Int32 PrintBmp(Int32 printID, Int32 type, String strPath);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Port_Close")]
        static extern Int32 Close(Int32 printID);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Output_PrintFontStringA")]
        static extern Int32 PrintFontStringA(Int32 printID, Int32 font, bool thick, Int32 width, Int32 height, bool underline, String str);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Output_PrintFontStringW")]
        static extern Int32 PrintFontStringW(Int32 printID, Int32 font, bool thick, Int32 width, Int32 height, bool underline, String str);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Control_SetPrintFontC")]
        static extern Int32 SetPrintFontC(Int32 printID, bool DoubleWidth, bool DoubleHeight, bool underline);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Control_SetPrintFontE")]
        static extern Int32 SetPrintFontE(Int32 printID, bool eFont, bool eBold, bool DoubleWidth, bool DoubleHeight, bool underline);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Control_AlignType")]
        static extern Int32 AlignType(Int32 printID, Int32 type);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Control_FeedLines")]
        static extern Int32 FeedLines(Int32 printID, Int32 DotLines);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Input_PrinterId")]
        static extern Int32 GetPrinterID(Int32 printID, StringBuilder Buff);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Input_ReadPrinter")]
        static extern Int32 GetPrinterData(Int32 printID, StringBuilder Buff);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Control_CashDraw")]
        static extern Int32 CashDraw(Int32 printID, Int32 iNum, Int32 time1, Int32 time2);

        [DllImport("..\\..\\..\\..\\..\\sdk\\POS_SDK.dll", CharSet = CharSet.Ansi, EntryPoint = "POS_Control_DownloadBmpToFlashNumA")]
        static extern Int32 DownloadBmpToFlashNumA(Int32 printID, String strPath, Int32 num);
        


        private enum iPortType { COM = 0, LPT, USB, NET };
        private iPortType m_pt;
        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            m_pt = iPortType.COM;
            textBox3.Text = "COM1:9600,N,8,1";
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            m_pt = iPortType.LPT;
            textBox3.Text = "LPT1:";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            m_pt = iPortType.USB;
            textBox3.Text = "SP-USB1"; // SP-USB(1~5)
        }

        private void radioButton4_CheckedChanged(object sender, EventArgs e)
        {
            m_pt = iPortType.NET;
            textBox3.Text = "192.168.1.203";
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Int32 ipt, sendNum, lp, llp;
            Int32 hPort;
            string strBuffer;
            StringBuilder buf = new StringBuilder();
            int iRet;
            
            switch (m_pt)
            {
                case iPortType.COM:
                    ipt = POS_PT_COM;
                    break;
                case iPortType.LPT:
                    ipt = POS_PT_LPT;
                    break;
                case iPortType.USB:
                    ipt = POS_PT_USB;
                    break;
                case iPortType.NET:
                    ipt = POS_PT_NET;
                    break;
                default:
                    ipt = POS_PT_COM;
                    break;
            }
            textBox1.Text = "Hi, thank you for choosing our printer, We will get your the best experience!\r\n感谢您选择我们的打印机\r\n\r\n";
            //textBox1.Text = "نقطة القبول يرسل  قوه قتل قيصر قيصر أستون أشهر الجفاف\n";            
           
            strBuffer = textBox3.Text;
            hPort = Open(strBuffer, ipt, false, "");
            if (hPort == 0)
            {
                MessageBox.Show("Open port failed!!");
                return;
            }
            strBuffer = textBox1.Text;
           
            sendNum = strBuffer.Length;
            string subStr;
            Int32 status;

            Thread.Sleep(100);

            llp = AlignType(hPort, 0);

            ReSet(hPort);
          
            //设置汉字字形
            llp = SetPrintFontC(hPort, CdWidthf, CdHeight, CudrLine);
          

            //设置西文字形
            llp = SetPrintFontE(hPort, Ecomprsf, Boldf, EdWidthf, EdHeight, EudrLine);
         
            llp = FeedLines(hPort, 200);

            while (sendNum > 0)
            {
                lp = Send(hPort, strBuffer);
                sendNum -= lp;
                if (sendNum > 0)
                {
                    subStr = strBuffer.Substring(lp);
                    strBuffer = subStr;
                    status = QueryStatus(hPort);
                    switch (status)
                    {
                        case POS_PS_PAPEROUT:
                            MessageBox.Show("打印机缺纸", "错误", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            System.Threading.Thread.Sleep(30000);
                            break;
                        case POS_PS_HEAT:
                            MessageBox.Show("打印机机头过热", "错误", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            System.Threading.Thread.Sleep(30000);
                            break;
                        case POS_PS_DOOROPEN:
                            MessageBox.Show("打印机纸仓门开", "错误", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            System.Threading.Thread.Sleep(30000);
                            break;
                        case POS_PS_BUFFEROUT:
                            MessageBox.Show("打印机缓冲区满", "错误", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            System.Threading.Thread.Sleep(10000);
                            break;
                        case POS_PS_CUT:
                            MessageBox.Show("打印机切刀错误", "错误", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            System.Threading.Thread.Sleep(30000);
                            break;
                        default:
                            break;
                    }
                }
            }

        
            // Print a barcode
            PrintBarcode(hPort, POS_BT_CODE39, 30, 50, POS_HT_DOWN, "123457890");
           
            PrintBarcode(hPort, POS_BT_CODE39, 30, 50, POS_HT_DOWN, "12345");

            PrintBarcode(hPort, POS_BT_PDF417, 2, 6, 1, "www.sina.com-中国");

            PrintBarcode(hPort, POS_BT_DATAMATRIX, 40, 40, 4, "www.sina.com-北京市");
         
            PrintBarcode(hPort, POS_BT_QRCODE, 2, 77, 4, "www.sina.com-石家庄");
           
            //PrintBmp(hPort, 0, textBox2.Text);

            //CashDraw(hPort, 1, 100, 100);          

            //iRet = DownloadBmpToFlashNumA(hPort, "..\\..\\..\\..\\..\\bmp\\logo_final_512x199.bmp", 0);
            //if (iRet == 3)
            //    MessageBox.Show("BMP Download success!!");

            byte[] cmd = { 0x1d, 0x56, 0x42, 0x00 };//切纸
            SendData(hPort, cmd, 4);            


            //GetPrinterData(hPort, buf);

            //if (buf.ToString() == "7\"1234")
            //    MessageBox.Show("data printed completely");
            //else
            //    MessageBox.Show("data printed uncompletely");    

            Thread.Sleep(100);
            
            Close(hPort);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            m_pt = iPortType.COM;
            radioButton1.Checked = true;
            textBox1.Text = "Hi, thank you for choosing our printer, We will get your the best experience!\r\n感谢您选择我们的打印机\r\n\r\n";
            textBox2.Text = "..\\..\\..\\..\\..\\bmp\\goodwork.bmp";
        }

        private void checkBox7_CheckedChanged_1(object sender, EventArgs e)
        {
            if (checkBox7.Checked)
                Boldf = true;
            else Boldf = false;
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
                EdWidthf = true;
            else EdWidthf = false;
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked)
                EdHeight = true;
            else EdHeight = false;
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox3.Checked)
                EudrLine = true;
            else EudrLine = false;
        }

        private void checkBox5_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox5.Checked)
                CdWidthf = true;
            else CdWidthf = false;
        }

        private void checkBox6_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox6.Checked)
                CdHeight = true;
            else CdHeight = false;
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox4.Checked)
                CudrLine = true;
            else CudrLine = false;
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox8.Checked)
                Ecomprsf = true;
            else Ecomprsf = false;
        }

        //查询打印机状态
        private void button4_Click(object sender, EventArgs e)
        {
            Int32 ipt, sendNum, lp, llp;
            Int32 hPort;
            string strBuffer;
            string strStatus = null;

            switch (m_pt)
            {
                case iPortType.COM:
                    ipt = POS_PT_COM;
                    break;
                case iPortType.LPT:
                    ipt = POS_PT_LPT;
                    break;
                case iPortType.USB:
                    ipt = POS_PT_USB;
                    break;
                case iPortType.NET:
                    ipt = POS_PT_NET;
                    break;
                default:
                    ipt = POS_PT_COM;
                    break;
            }
            strBuffer = textBox3.Text;
            hPort = Open(strBuffer, ipt, false, "");
            if (hPort == 0)
            {
                MessageBox.Show("Open port failed!!");
                return;
            }

            Int32 status = 0;


            //RTQueryStatus(hPort, n);
            //n=1:钱箱高电平；n=2:纸仓盖开；n=3:切刀错；n=4:缺纸

            status = RTQueryTypeStatus(hPort, 1);
            if (status != 0)
            {
                switch (status)
                {
                    case POS_PS_DRAWERHIGH:
                        strStatus = "/钱箱高电平/";
                        System.Threading.Thread.Sleep(300);
                        break;
                    default:
                        break;
                }
            }
            else MessageBox.Show("查钱箱时错!");

            System.Threading.Thread.Sleep(300);
            status = RTQueryTypeStatus(hPort, 2);
            if (status != 0)
            {
                switch (status)
                {
                    case POS_PS_DOOROPEN:
                        strStatus += "/纸仓盖开/";
                        System.Threading.Thread.Sleep(300);
                        break;
                    default:
                        break;
                }
            }
            else MessageBox.Show("查仓盖时错!");

            System.Threading.Thread.Sleep(300);
            status = RTQueryTypeStatus(hPort, 3);
            if (status != 0)
            {
                switch (status)
                {
                    case POS_PS_CUT:
                        strStatus += "/切刀错误/";
                        System.Threading.Thread.Sleep(300);
                        break;
                    default:
                        break;
                }
            }
            else MessageBox.Show("查切刀时错!");


            System.Threading.Thread.Sleep(300);
            status = RTQueryTypeStatus(hPort, 4);
            if (status != 0)
            {
                switch (status)
                {
                    case POS_PS_PAPEROUT:
                        strStatus += "/打印机缺纸/";
                        System.Threading.Thread.Sleep(300);
                        break;
                    default:
                        break;
                }
            }
            else MessageBox.Show("查缺纸时错!");

            if (!string.IsNullOrEmpty(strStatus))
                MessageBox.Show(strStatus);

            Close(hPort);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Int32 ipt, sendNum, lp, llp;
            Int32 hPort;
            string strBuffer;
            string strStatus = null;
            StringBuilder Idbuf = new StringBuilder();


            string a;

            switch (m_pt)
            {
                case iPortType.COM:
                    ipt = POS_PT_COM;
                    break;
                case iPortType.LPT:
                    ipt = POS_PT_LPT;
                    break;
                case iPortType.USB:
                    ipt = POS_PT_USB;
                    break;
                case iPortType.NET:
                    ipt = POS_PT_NET;
                    break;
                default:
                    ipt = POS_PT_COM;
                    break;
            }
            strBuffer = textBox3.Text;
            hPort = Open(strBuffer, ipt, false, "");
            if (hPort == 0)
            {
                MessageBox.Show("Open port failed!!");
                return;
            }

            Thread.Sleep(100);
            int iRet = GetPrinterID(hPort, Idbuf);

            if (iRet > 0)
            {
                textBox1.Text += Idbuf.ToString() + " ";
            }
            else
                textBox1.Text = "";

            Thread.Sleep(100);
            Close(hPort);
        }

        private void Form1_Deactivate(object sender, EventArgs e)
        {            
            
        }
    }
}