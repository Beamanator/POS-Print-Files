<?php
/* attempting to reproduce custom-command [specific example 141] */

require __DIR__ . '/../autoload.php';
use Mike42\Escpos\Printer;
use Mike42\Escpos\PrintConnectors\WindowsPrintConnector;
// use Mike42\Escpos\CapabilityProfiles\DefaultCapabilityProfile;

try {
	// Enter the share name for your USB printer here
	$connector = new WindowsPrintConnector("SPRT POS Printer");
	// $profile = DefaultCapabilityProfile::getInstance(); // Works for Epson printers
	$printer = new Printer($connector);

	/*
	 * Make the command.
	 * This is documented on page A-14 of:
	 * https://files.support.epson.com/pdf/lx300p/lx300pu1.pdf
	 */
	// $m = chr(EAN13);
	// $n = intLowHigh(strlen($content), 2);
	// not supported by my printer:
	// $barcodeCommand = Printer::ESC . "G(" . $m . $n . $content;

	/* Print some bold text */
	$printer -> setEmphasis(true);
	$printer -> text("Alex test 3 - bmp\n");
	$printer -> setEmphasis(false);
	// $printer -> feed();

	// example printing rotated images, and in German i think
	// $cmd = Printer::ESC . "V" . chr(1); // Try out 90-degree rotation.
	// $printer -> getPrintConnector() -> write($cmd);
	// $printer -> text("Beispieltext in Deutsch\n");

	// testing printing images:
	// $m = chr(0);
	// $nL = chr(3); // 0 <= nL <= 255
	// $nH = chr(3); // 0 <= nH <= 3
	// $content = chr(0) . chr(1) . chr(0) . chr(1) . chr(1) . chr(1) . chr(0) . chr(0) . chr(0);
	// try this $content next:
	// $content = chr(0)1 . chr(1)2 . chr(0)3 . chr(1)4 . chr(1)5 . chr(1)6 . chr(0)7 . chr(0)8 . chr(0)9;	

	// $cmd = Printer::ESC . '*' . $m . $nL . $nH . $content;
	// $printer -> getPrintConnector() -> write($cmd);

	/* cut paper & close printer */
	$printer -> cut();
	$printer -> close();
} catch(Exception $e) {
	echo "Couldn't print to this printer: " . $e -> getMessage() . "\n";
}

// function intLowHigh($input, $length)
// {
//     $outp = "";
//     for ($i = 0; $i < $length; $i ++) {
//         $outp .= chr($input % 256);
//         $input = (int) ($input / 256);
//     }
//     return $outp;
// }